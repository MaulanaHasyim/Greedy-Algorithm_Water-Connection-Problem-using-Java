/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package water.connection;

import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author Maulana Hasyim
 * 11180910000043
 */
public class GenerateOutput {
    
    public GenerateOutput(ArrayList<ArrayList<Integer>> hasil, JLabel hasilUtama, JPanel tangkiHasil, JPanel keranHasil, JPanel diameterPipaHasil) {
        clearPanel(hasilUtama, tangkiHasil, keranHasil, diameterPipaHasil);
        hasilUtama.setText(String.valueOf(hasil.get(0).size()));
        for (int i = 0; i < hasil.get(0).size(); i++) {
            GenerateOneRowLabel label = new GenerateOneRowLabel(tangkiHasil, keranHasil, diameterPipaHasil);
            label.setValue(hasil.get(0).get(i), hasil.get(1).get(i), hasil.get(2).get(i));
        }
    }
    
    private void clearPanel (JLabel hasilUtama, JPanel tangkiHasil, JPanel keranHasil, JPanel diameterPipaHasil){
        tangkiHasil.removeAll();
        keranHasil.removeAll();
        diameterPipaHasil.removeAll();
        tangkiHasil.revalidate();
        keranHasil.revalidate();
        diameterPipaHasil.revalidate();
        tangkiHasil.repaint();
        keranHasil.repaint();
        diameterPipaHasil.repaint();
        hasilUtama.setText("0");
    }
    
}
