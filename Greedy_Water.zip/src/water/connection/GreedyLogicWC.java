/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package water.connection;

import java.util.ArrayList;
import java.util.LinkedList;

/**
 *
 * @author Maulana Hasyim
 * 11180910000043
 */
public class GreedyLogicWC {
    // number of houses and number 
    // of pipes 
    private int n, p; 
  
    // Array rd stores the  
    // ending vertex of pipe 
    private int rd[] = new int[1100]; 
  
    // Array wd stores the value  
    // of diameters between two pipes 
    private int wt[] = new int[1100]; 
  
    // Array cd stores the  
    // starting end of pipe 
    private int cd[] = new int[1100]; 
  
    // arraylist a, b, c are used 
    // to store the final output 
    private ArrayList<ArrayList<Integer>> hasil = new ArrayList<ArrayList<Integer>>();
    
    private ArrayList <Integer> a =  
              new ArrayList<Integer>(); 
                
    private ArrayList <Integer> b =  
              new ArrayList<Integer>(); 
                
    private ArrayList <Integer> c =  
              new ArrayList<Integer>(); 
      
    private int ans; 
    
    public GreedyLogicWC (int n, int p, LinkedList<LinkedList<Integer>> arr) {
        setValue(n, p);
        solve(arr);
    }
      
    private int dfs(int w) 
    { 
        if (this.cd[w] == 0) 
            return w; 
        if (this.wt[w] < this.ans) 
            this.ans = this.wt[w]; 
              
        return dfs(this.cd[w]); 
    } 
  
    // Function to perform calculations. 
    private void solve(LinkedList<LinkedList<Integer>> arr) 
    { 
        int i = 0; 
      
        while (i < this.p) 
        { 
              
            int q = arr.get(i).get(0); 
            int h = arr.get(i).get(1); 
            int t = arr.get(i).get(2);
              
            this.cd[q] = h; 
            this.wt[q] = t; 
            this.rd[h] = q; 
            i++; 
        } 
          
        this.a=new ArrayList<Integer>(); 
        this.c=new ArrayList<Integer>(); 
        this.c=new ArrayList<Integer>(); 
          
        for (int j = 1; j <= this.n; ++j) 
          
            /*If a pipe has no ending vertex  
            but has starting vertex i.e is  
            an outgoing pipe then we need  
            to start DFS with this vertex.*/
            if (this.rd[j] == 0 && this.cd[j]>0) { 
                this.ans = 1000000000; 
                int w = dfs(j); 
                  
                // We put the details of 
                // component in final output 
                // array 
                this.a.add(j); 
                this.b.add(w); 
                this.c.add(this.ans); 
            }
        
        this.hasil.add(this.a);
        this.hasil.add(this.b);
        this.hasil.add(this.c); 
    }
    
    public void lihatHasil () {      
        ArrayList<ArrayList<Integer>> hasil = getHasil();
        System.out.println(hasil.get(0).size());
        for (int j = 0; j < hasil.get(0).size(); ++j) 
            System.out.println(hasil.get(0).get(j) + " " 
                + hasil.get(1).get(j) + " " + hasil.get(2).get(j)); 
    }
    
    public ArrayList<ArrayList<Integer>> getHasil () {
        return this.hasil;
    }
    
    private void setValue (int rumah, int pipa) {
        setN(rumah);
        setP(pipa);
    }

    private void setN(int n) {
        this.n = n;
    }

    private void setP(int p) {
        this.p = p;
    }
}
