/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package water.connection;

import java.awt.Dimension;
import javax.swing.*;

/**
 *
 * @author Maulana Hasyim
 * 11180910000043
 */
public class GenerateOneRowLabel {
    
    private JLabel tangkiHasilLabel = new JLabel();
    private JLabel keranHasilLabel = new JLabel();
    private JLabel diameterPipaHasilLabel = new JLabel();
    
    public GenerateOneRowLabel (JPanel hasilTangki, JPanel hasilKeran, JPanel hasilDiameterPipa) {
        makeLabelHasil(hasilTangki, getTangkiHasilLabel());
        makeLabelHasil(hasilKeran, getKeranHasilLabel());
        makeLabelHasil(hasilDiameterPipa, getDiameterPipaHasilLabel());
    }
    
    private void makeLabelHasil (JPanel inputRumahPanel, JLabel labelHasilBaru) {
        inputRumahPanel.add(labelHasilBaru);
        labelHasilBaru.setPreferredSize(new Dimension(100, 20));
        labelHasilBaru.setMinimumSize(new Dimension(100, 20));
        labelHasilBaru.setMaximumSize(new Dimension(100, 20));
        labelHasilBaru.setFont(new java.awt.Font("Open Sans", 1, 14));
        labelHasilBaru.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        inputRumahPanel.revalidate();
    }
    
    public void setValue (int tangki, int keran, int diameterPipa) {
        setTangkiHasilLabel(tangki);
        setKeranHasilLabel(keran);
        setDiameterPipaHasilLabel(diameterPipa);
    }

    private JLabel getTangkiHasilLabel() {
        return tangkiHasilLabel;
    }

    private void setTangkiHasilLabel(int value) {
        getTangkiHasilLabel().setText(String.valueOf(value));
    }

    private JLabel getKeranHasilLabel() {
        return keranHasilLabel;
    }

    private void setKeranHasilLabel(int value) {
        getKeranHasilLabel().setText(String.valueOf(value));
    }

    private JLabel getDiameterPipaHasilLabel() {
        return diameterPipaHasilLabel;
    }

    private void setDiameterPipaHasilLabel(int value) {
        getDiameterPipaHasilLabel().setText(String.valueOf(value));
    }
    
}
