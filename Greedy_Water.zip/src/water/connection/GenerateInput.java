/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package water.connection;

import java.awt.Dimension;
import java.util.LinkedList;
import javax.swing.*;

/**
 *
 * @author Maulana Hasyim
 * 11180910000043
 */
public class GenerateInput {
   
    private LinkedList<GenerateOneRowTextField> input = new LinkedList<GenerateOneRowTextField>();
    private LinkedList<LinkedList<Integer>> hasil = new LinkedList<LinkedList<Integer>>();
    
    public GenerateInput(int jumlahPipa, JPanel inputRumahAwal, JPanel inputRumahAkhir, JPanel inputDiameterPipa) {
        clearPanel(inputRumahAwal, inputRumahAkhir, inputDiameterPipa);
        for (int i = 0; i < jumlahPipa; i++) {
            addInput(new GenerateOneRowTextField(inputRumahAwal, inputRumahAkhir, inputDiameterPipa));
        }
    }
    
    private void clearPanel (JPanel inputRumahAwal, JPanel inputRumahAkhir, JPanel inputDiameterPipa){
        inputRumahAwal.removeAll();
        inputRumahAkhir.removeAll();
        inputDiameterPipa.removeAll();
        inputRumahAwal.revalidate();
        inputRumahAkhir.revalidate();
        inputDiameterPipa.revalidate();
        inputRumahAwal.repaint();
        inputRumahAkhir.repaint();
        inputDiameterPipa.repaint();
        LinkedList<LinkedList<Integer>> temp = new LinkedList<LinkedList<Integer>>();
        for (int i = 0; i < temp.size(); i++) {
            temp.remove(i);
        }
    }

    public LinkedList<LinkedList<Integer>> getHasil() {
        return hasil;
    }

    private void addHasil(LinkedList<Integer> hasil) {
        getHasil().add(hasil);
    }
    
    private void addInput (GenerateOneRowTextField input) {
        getInput().add(input);
    }
    
    public void passHasil () {
        for (int i = 0; i < getInput().size(); i++) {
            getInput().get(i).setDataValue();
            addHasil(getInput().get(i).getDataRow());
        }
    }

    private LinkedList<GenerateOneRowTextField> getInput() {
        return input;
    }
    
}
