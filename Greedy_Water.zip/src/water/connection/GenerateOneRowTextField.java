/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package water.connection;

import java.awt.Dimension;
import java.util.LinkedList;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author Maulana Hasyim
 * 11180910000043
 */
public class GenerateOneRowTextField {
    
    private LinkedList<Integer> dataRow = new LinkedList<Integer>();
    private JTextField rumahAwalField = new JTextField();
    private JTextField rumahAkhirField = new JTextField();
    private JTextField diameterPipaField = new JTextField();
    
    public GenerateOneRowTextField (JPanel inputRumahAwal, JPanel inputRumahAkhir, JPanel inputDiameterPipa) {
        makeTextField(inputRumahAwal, getRumahAwalField());
        makeTextField(inputRumahAkhir, getRumahAkhirField());
        makeTextField(inputDiameterPipa, getDiameterPipaField());
    }
    
    private void makeTextField (JPanel inputRumahPanel, JTextField textFieldBaru) {
        inputRumahPanel.add(textFieldBaru);
        textFieldBaru.setPreferredSize(new Dimension(80, 30));
        textFieldBaru.setMinimumSize(new Dimension(80, 30));
        textFieldBaru.setMaximumSize(new Dimension(80, 30));
        inputRumahPanel.revalidate();
    }
    
    public void setDataValue () {
        int dataRumahAwal = Integer.parseInt(getRumahAwalField().getText());
        int dataRumahAkhir = Integer.parseInt(getRumahAkhirField().getText());
        int dataDiameterPipa = Integer.parseInt(getDiameterPipaField().getText());
        
        getDataRow().add(dataRumahAwal);
        getDataRow().add(dataRumahAkhir);
        getDataRow().add(dataDiameterPipa);
    }

    private JTextField getRumahAwalField() {
        return this.rumahAwalField;
    }

    private JTextField getRumahAkhirField() {
        return this.rumahAkhirField;
    }

    private JTextField getDiameterPipaField() {
        return this.diameterPipaField;
    }

    public LinkedList<Integer> getDataRow() {
        return dataRow;
    }
}
